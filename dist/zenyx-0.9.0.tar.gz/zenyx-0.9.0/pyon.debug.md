
<br>`00:25:45:666` | 
<br>`00:25:45:666` | **`======================= [Deep Serialize] =======================`**
<br>`00:25:45:666` | 
<br>`00:25:45:666` | 
<br>`00:25:45:667` | 
<br>`00:25:45:667` | **`========================== [Start: 1] ==========================`**
<br>`00:25:45:667` | 
<br>`00:25:45:667` | 
<br>`00:25:45:667` |   **`[1]`** Original obj input:
<br>`00:25:45:667` |   	&emsp;`test(testParam=[[[test(testParam='asd')]]])`
<br>`00:25:45:667` | 
<br>`00:25:45:669` |   **`[TypeCheck]`** Checking Type 
<br>`00:25:45:669` |   	&emsp;Value: `test(testParam=[[[test(testParam='asd')]]])`, 
<br>`00:25:45:669` |   	&emsp;Type(s): `(<class 'dict'>, <class 'list'>, <class 'tuple'>)`
<br>`00:25:45:669` | 
<br>`00:25:45:670` |   **`[1]`** Iterability test:
<br>`00:25:45:670` |   	&emsp;**Params:**
<br>`00:25:45:670` |   	&emsp;	&emsp;Value: `test(testParam=[[[test(testParam='asd')]]])`
<br>`00:25:45:670` |   	&emsp;	&emsp;@Type: `<class '__main__.test'>`
<br>`00:25:45:670` |   	&emsp;Is object *(`__is_object`)*: `True`
<br>`00:25:45:670` |   	&emsp;Is dict/list/tuple *(`test1`)*: `False`
<br>`00:25:45:670` |   	&emsp;**Final Resoult**: `True`
<br>`00:25:45:670` | 
<br>`00:25:45:671` |   **`[1]`** Original Obj Iterability *(can be `False`)*:
<br>`00:25:45:671` |   	&emsp;Object *(`obj`)*: `test(testParam=[[[test(testParam='asd')]]])` 
<br>`00:25:45:671` |   	&emsp;**Is object iterable**: `True`
<br>`00:25:45:671` | 
<br>`00:25:45:671` |   **`[TypeCheck]`** Checking Type 
<br>`00:25:45:671` |   	&emsp;Value: `test(testParam=[[[test(testParam='asd')]]])`, 
<br>`00:25:45:671` |   	&emsp;Type(s): `(<class 'dict'>, <class 'list'>, <class 'tuple'>)`
<br>`00:25:45:671` | 
<br>`00:25:45:672` |   **`[1]`** Iterability test:
<br>`00:25:45:672` |   	&emsp;**Params:**
<br>`00:25:45:672` |   	&emsp;	&emsp;Value: `test(testParam=[[[test(testParam='asd')]]])`
<br>`00:25:45:672` |   	&emsp;	&emsp;@Type: `<class '__main__.test'>`
<br>`00:25:45:672` |   	&emsp;Is object *(`__is_object`)*: `True`
<br>`00:25:45:672` |   	&emsp;Is dict/list/tuple *(`test1`)*: `False`
<br>`00:25:45:672` |   	&emsp;**Final Resoult**: `True`
<br>`00:25:45:672` | 
<br>`00:25:45:673` |   **`[TypeCheck]`** Checking Type 
<br>`00:25:45:673` |   	&emsp;Value: `test(testParam=[[[test(testParam='asd')]]])`, 
<br>`00:25:45:673` |   	&emsp;Type(s): `<class 'dict'>`
<br>`00:25:45:673` | 
<br>`00:25:45:674` |   **`[TypeCheck]`** Checking Type 
<br>`00:25:45:674` |   	&emsp;Value: `test(testParam=[[[test(testParam='asd')]]])`, 
<br>`00:25:45:674` |   	&emsp;Type(s): `<class 'dict'>`
<br>`00:25:45:674` | 
<br>`00:25:45:675` |   **`[TypeCheck]`** Checking Type 
<br>`00:25:45:675` |   	&emsp;Value: `test(testParam=[[[test(testParam='asd')]]])`, 
<br>`00:25:45:675` |   	&emsp;Type(s): `(<class 'list'>, <class 'tuple'>)`
<br>`00:25:45:675` | 
<br>`00:25:45:675` |   **`[TypeCheck]`** Checking Type 
<br>`00:25:45:675` |   	&emsp;Value: `[[[test(testParam='asd')]]]`, 
<br>`00:25:45:675` |   	&emsp;Type(s): `(<class 'list'>, <class 'tuple'>)`
<br>`00:25:45:675` | 
<br>`00:25:45:676` |   **`[TypeCheck]`** Checking Type 
<br>`00:25:45:676` |   	&emsp;Value: `[[test(testParam='asd')]]`, 
<br>`00:25:45:676` |   	&emsp;Type(s): `(<class 'dict'>, <class 'list'>, <class 'tuple'>)`
<br>`00:25:45:676` | 
<br>`00:25:45:678` |   **`[1]`** Iterability test:
<br>`00:25:45:678` |   	&emsp;**Params:**
<br>`00:25:45:678` |   	&emsp;	&emsp;Value: `[[test(testParam='asd')]]`
<br>`00:25:45:678` |   	&emsp;	&emsp;@Type: `<class 'list'>`
<br>`00:25:45:678` |   	&emsp;Is object *(`__is_object`)*: `False`
<br>`00:25:45:678` |   	&emsp;Is dict/list/tuple *(`test1`)*: `True`
<br>`00:25:45:678` |   	&emsp;**Final Resoult**: `True`
<br>`00:25:45:678` | 
<br>`00:25:45:678` | 
<br>`00:25:45:678` | **`================= [Deep Serialize - Caller: 1] =================`**
<br>`00:25:45:678` | 
<br>`00:25:45:678` | 
<br>`00:25:45:679` | 
<br>`00:25:45:679` | **`==================== [Start: 2 - Caller: 1] ====================`**
<br>`00:25:45:679` | 
<br>`00:25:45:679` | 
<br>`00:25:45:681` |   **`[2]`** Original obj input:
<br>`00:25:45:681` |   	&emsp;`[[test(testParam='asd')]]`
<br>`00:25:45:681` | 
<br>`00:25:45:681` |   **`[TypeCheck]`** Checking Type 
<br>`00:25:45:681` |   	&emsp;Value: `[[test(testParam='asd')]]`, 
<br>`00:25:45:681` |   	&emsp;Type(s): `(<class 'dict'>, <class 'list'>, <class 'tuple'>)`
<br>`00:25:45:681` | 
<br>`00:25:45:683` |   **`[2]`** Iterability test:
<br>`00:25:45:683` |   	&emsp;**Params:**
<br>`00:25:45:683` |   	&emsp;	&emsp;Value: `[[test(testParam='asd')]]`
<br>`00:25:45:683` |   	&emsp;	&emsp;@Type: `<class 'list'>`
<br>`00:25:45:683` |   	&emsp;Is object *(`__is_object`)*: `False`
<br>`00:25:45:683` |   	&emsp;Is dict/list/tuple *(`test1`)*: `True`
<br>`00:25:45:683` |   	&emsp;**Final Resoult**: `True`
<br>`00:25:45:683` | 
<br>`00:25:45:684` |   **`[2]`** Original Obj Iterability *(can be `False`)*:
<br>`00:25:45:684` |   	&emsp;Object *(`obj`)*: `[[test(testParam='asd')]]` 
<br>`00:25:45:684` |   	&emsp;**Is object iterable**: `True`
<br>`00:25:45:684` | 
<br>`00:25:45:685` |   **`[TypeCheck]`** Checking Type 
<br>`00:25:45:685` |   	&emsp;Value: `[[test(testParam='asd')]]`, 
<br>`00:25:45:685` |   	&emsp;Type(s): `(<class 'dict'>, <class 'list'>, <class 'tuple'>)`
<br>`00:25:45:685` | 
<br>`00:25:45:687` |   **`[2]`** Iterability test:
<br>`00:25:45:687` |   	&emsp;**Params:**
<br>`00:25:45:687` |   	&emsp;	&emsp;Value: `[[test(testParam='asd')]]`
<br>`00:25:45:687` |   	&emsp;	&emsp;@Type: `<class 'list'>`
<br>`00:25:45:687` |   	&emsp;Is object *(`__is_object`)*: `False`
<br>`00:25:45:687` |   	&emsp;Is dict/list/tuple *(`test1`)*: `True`
<br>`00:25:45:687` |   	&emsp;**Final Resoult**: `True`
<br>`00:25:45:687` | 
<br>`00:25:45:687` |   **`[TypeCheck]`** Checking Type 
<br>`00:25:45:687` |   	&emsp;Value: `[[test(testParam='asd')]]`, 
<br>`00:25:45:687` |   	&emsp;Type(s): `<class 'dict'>`
<br>`00:25:45:687` | 
<br>`00:25:45:689` |   **`[TypeCheck]`** Checking Type 
<br>`00:25:45:689` |   	&emsp;Value: `[[test(testParam='asd')]]`, 
<br>`00:25:45:689` |   	&emsp;Type(s): `<class 'dict'>`
<br>`00:25:45:689` | 
<br>`00:25:45:689` |   **`[TypeCheck]`** Checking Type 
<br>`00:25:45:689` |   	&emsp;Value: `[[test(testParam='asd')]]`, 
<br>`00:25:45:689` |   	&emsp;Type(s): `(<class 'list'>, <class 'tuple'>)`
<br>`00:25:45:689` | 
<br>`00:25:45:690` |   **`[2]`** Iterating List/Tuple:
<br>`00:25:45:690` |   	&emsp;List/Tuple *(`obj`)*: `[[test(testParam='asd')]]`
<br>`00:25:45:690` |   	&emsp;Element: `[test(testParam='asd')]`
<br>`00:25:45:690` | 
<br>`00:25:45:690` |   **`[TypeCheck]`** Checking Type 
<br>`00:25:45:690` |   	&emsp;Value: `[test(testParam='asd')]`, 
<br>`00:25:45:690` |   	&emsp;Type(s): `(<class 'dict'>, <class 'list'>, <class 'tuple'>)`
<br>`00:25:45:690` | 
<br>`00:25:45:692` |   **`[2]`** Iterability test:
<br>`00:25:45:692` |   	&emsp;**Params:**
<br>`00:25:45:692` |   	&emsp;	&emsp;Value: `[test(testParam='asd')]`
<br>`00:25:45:692` |   	&emsp;	&emsp;@Type: `<class 'list'>`
<br>`00:25:45:692` |   	&emsp;Is object *(`__is_object`)*: `False`
<br>`00:25:45:692` |   	&emsp;Is dict/list/tuple *(`test1`)*: `True`
<br>`00:25:45:692` |   	&emsp;**Final Resoult**: `True`
<br>`00:25:45:692` | 
<br>`00:25:45:693` | 
<br>`00:25:45:693` | **`================= [Deep Serialize - Caller: 2] =================`**
<br>`00:25:45:693` | 
<br>`00:25:45:693` | 
<br>`00:25:45:694` | 
<br>`00:25:45:694` | **`==================== [Start: 3 - Caller: 2] ====================`**
<br>`00:25:45:694` | 
<br>`00:25:45:694` | 
<br>`00:25:45:695` |   **`[3]`** Original obj input:
<br>`00:25:45:695` |   	&emsp;`[test(testParam='asd')]`
<br>`00:25:45:695` | 
<br>`00:25:45:696` |   **`[TypeCheck]`** Checking Type 
<br>`00:25:45:696` |   	&emsp;Value: `[test(testParam='asd')]`, 
<br>`00:25:45:696` |   	&emsp;Type(s): `(<class 'dict'>, <class 'list'>, <class 'tuple'>)`
<br>`00:25:45:696` | 
<br>`00:25:45:697` |   **`[3]`** Iterability test:
<br>`00:25:45:697` |   	&emsp;**Params:**
<br>`00:25:45:697` |   	&emsp;	&emsp;Value: `[test(testParam='asd')]`
<br>`00:25:45:697` |   	&emsp;	&emsp;@Type: `<class 'list'>`
<br>`00:25:45:697` |   	&emsp;Is object *(`__is_object`)*: `False`
<br>`00:25:45:697` |   	&emsp;Is dict/list/tuple *(`test1`)*: `True`
<br>`00:25:45:697` |   	&emsp;**Final Resoult**: `True`
<br>`00:25:45:697` | 
<br>`00:25:45:699` |   **`[3]`** Original Obj Iterability *(can be `False`)*:
<br>`00:25:45:699` |   	&emsp;Object *(`obj`)*: `[test(testParam='asd')]` 
<br>`00:25:45:699` |   	&emsp;**Is object iterable**: `True`
<br>`00:25:45:699` | 
<br>`00:25:45:699` |   **`[TypeCheck]`** Checking Type 
<br>`00:25:45:699` |   	&emsp;Value: `[test(testParam='asd')]`, 
<br>`00:25:45:699` |   	&emsp;Type(s): `(<class 'dict'>, <class 'list'>, <class 'tuple'>)`
<br>`00:25:45:699` | 
<br>`00:25:45:701` |   **`[3]`** Iterability test:
<br>`00:25:45:701` |   	&emsp;**Params:**
<br>`00:25:45:701` |   	&emsp;	&emsp;Value: `[test(testParam='asd')]`
<br>`00:25:45:701` |   	&emsp;	&emsp;@Type: `<class 'list'>`
<br>`00:25:45:701` |   	&emsp;Is object *(`__is_object`)*: `False`
<br>`00:25:45:701` |   	&emsp;Is dict/list/tuple *(`test1`)*: `True`
<br>`00:25:45:701` |   	&emsp;**Final Resoult**: `True`
<br>`00:25:45:701` | 
<br>`00:25:45:702` |   **`[TypeCheck]`** Checking Type 
<br>`00:25:45:702` |   	&emsp;Value: `[test(testParam='asd')]`, 
<br>`00:25:45:702` |   	&emsp;Type(s): `<class 'dict'>`
<br>`00:25:45:702` | 
<br>`00:25:45:702` |   **`[TypeCheck]`** Checking Type 
<br>`00:25:45:702` |   	&emsp;Value: `[test(testParam='asd')]`, 
<br>`00:25:45:702` |   	&emsp;Type(s): `<class 'dict'>`
<br>`00:25:45:702` | 
<br>`00:25:45:703` |   **`[TypeCheck]`** Checking Type 
<br>`00:25:45:703` |   	&emsp;Value: `[test(testParam='asd')]`, 
<br>`00:25:45:703` |   	&emsp;Type(s): `(<class 'list'>, <class 'tuple'>)`
<br>`00:25:45:703` | 
<br>`00:25:45:704` |   **`[3]`** Iterating List/Tuple:
<br>`00:25:45:704` |   	&emsp;List/Tuple *(`obj`)*: `[test(testParam='asd')]`
<br>`00:25:45:704` |   	&emsp;Element: `test(testParam='asd')`
<br>`00:25:45:704` | 
<br>`00:25:45:704` |   **`[TypeCheck]`** Checking Type 
<br>`00:25:45:704` |   	&emsp;Value: `test(testParam='asd')`, 
<br>`00:25:45:704` |   	&emsp;Type(s): `(<class 'dict'>, <class 'list'>, <class 'tuple'>)`
<br>`00:25:45:704` | 
<br>`00:25:45:706` |   **`[3]`** Iterability test:
<br>`00:25:45:706` |   	&emsp;**Params:**
<br>`00:25:45:706` |   	&emsp;	&emsp;Value: `test(testParam='asd')`
<br>`00:25:45:706` |   	&emsp;	&emsp;@Type: `<class '__main__.test'>`
<br>`00:25:45:706` |   	&emsp;Is object *(`__is_object`)*: `True`
<br>`00:25:45:706` |   	&emsp;Is dict/list/tuple *(`test1`)*: `False`
<br>`00:25:45:706` |   	&emsp;**Final Resoult**: `True`
<br>`00:25:45:706` | 
<br>`00:25:45:706` | 
<br>`00:25:45:706` | **`================= [Deep Serialize - Caller: 3] =================`**
<br>`00:25:45:706` | 
<br>`00:25:45:706` | 
<br>`00:25:45:707` | 
<br>`00:25:45:707` | **`==================== [Start: 4 - Caller: 3] ====================`**
<br>`00:25:45:707` | 
<br>`00:25:45:707` | 
<br>`00:25:45:708` |   **`[4]`** Original obj input:
<br>`00:25:45:708` |   	&emsp;`test(testParam='asd')`
<br>`00:25:45:708` | 
<br>`00:25:45:709` |   **`[TypeCheck]`** Checking Type 
<br>`00:25:45:709` |   	&emsp;Value: `test(testParam='asd')`, 
<br>`00:25:45:709` |   	&emsp;Type(s): `(<class 'dict'>, <class 'list'>, <class 'tuple'>)`
<br>`00:25:45:709` | 
<br>`00:25:45:710` |   **`[4]`** Iterability test:
<br>`00:25:45:710` |   	&emsp;**Params:**
<br>`00:25:45:710` |   	&emsp;	&emsp;Value: `test(testParam='asd')`
<br>`00:25:45:710` |   	&emsp;	&emsp;@Type: `<class '__main__.test'>`
<br>`00:25:45:710` |   	&emsp;Is object *(`__is_object`)*: `True`
<br>`00:25:45:710` |   	&emsp;Is dict/list/tuple *(`test1`)*: `False`
<br>`00:25:45:710` |   	&emsp;**Final Resoult**: `True`
<br>`00:25:45:710` | 
<br>`00:25:45:711` |   **`[4]`** Original Obj Iterability *(can be `False`)*:
<br>`00:25:45:711` |   	&emsp;Object *(`obj`)*: `test(testParam='asd')` 
<br>`00:25:45:711` |   	&emsp;**Is object iterable**: `True`
<br>`00:25:45:711` | 
<br>`00:25:45:712` |   **`[TypeCheck]`** Checking Type 
<br>`00:25:45:712` |   	&emsp;Value: `test(testParam='asd')`, 
<br>`00:25:45:712` |   	&emsp;Type(s): `(<class 'dict'>, <class 'list'>, <class 'tuple'>)`
<br>`00:25:45:712` | 
<br>`00:25:45:714` |   **`[4]`** Iterability test:
<br>`00:25:45:714` |   	&emsp;**Params:**
<br>`00:25:45:714` |   	&emsp;	&emsp;Value: `test(testParam='asd')`
<br>`00:25:45:714` |   	&emsp;	&emsp;@Type: `<class '__main__.test'>`
<br>`00:25:45:714` |   	&emsp;Is object *(`__is_object`)*: `True`
<br>`00:25:45:714` |   	&emsp;Is dict/list/tuple *(`test1`)*: `False`
<br>`00:25:45:714` |   	&emsp;**Final Resoult**: `True`
<br>`00:25:45:714` | 
<br>`00:25:45:715` |   **`[TypeCheck]`** Checking Type 
<br>`00:25:45:715` |   	&emsp;Value: `test(testParam='asd')`, 
<br>`00:25:45:715` |   	&emsp;Type(s): `<class 'dict'>`
<br>`00:25:45:715` | 
<br>`00:25:45:716` |   **`[TypeCheck]`** Checking Type 
<br>`00:25:45:716` |   	&emsp;Value: `test(testParam='asd')`, 
<br>`00:25:45:716` |   	&emsp;Type(s): `<class 'dict'>`
<br>`00:25:45:716` | 
<br>`00:25:45:717` |   **`[TypeCheck]`** Checking Type 
<br>`00:25:45:717` |   	&emsp;Value: `test(testParam='asd')`, 
<br>`00:25:45:717` |   	&emsp;Type(s): `(<class 'list'>, <class 'tuple'>)`
<br>`00:25:45:717` | 
<br>`00:25:45:718` |   **`[TypeCheck]`** Checking Type 
<br>`00:25:45:718` |   	&emsp;Value: `asd`, 
<br>`00:25:45:718` |   	&emsp;Type(s): `(<class 'list'>, <class 'tuple'>)`
<br>`00:25:45:718` | 
<br>`00:25:45:719` |   **`[TypeCheck]`** Checking Type 
<br>`00:25:45:719` |   	&emsp;Value: `asd`, 
<br>`00:25:45:719` |   	&emsp;Type(s): `<class 'dict'>`
<br>`00:25:45:719` | 
<br>`00:25:45:720` |   **`[TypeCheck]`** Checking Type 
<br>`00:25:45:720` |   	&emsp;Value: `test`, 
<br>`00:25:45:720` |   	&emsp;Type(s): `(<class 'list'>, <class 'tuple'>)`
<br>`00:25:45:720` | 
<br>`00:25:45:721` |   **`[TypeCheck]`** Checking Type 
<br>`00:25:45:721` |   	&emsp;Value: `test`, 
<br>`00:25:45:721` |   	&emsp;Type(s): `<class 'dict'>`
<br>`00:25:45:721` | 
<br>`00:25:45:722` |   **`[4]`** **New dict created:**
<br>`00:25:45:722` |   	&emsp;`{'testParam': 'asd', 'PYON_TYPE': 'test'}`
<br>`00:25:45:722` | 
<br>`00:25:45:723` | 
<br>`00:25:45:723` | **`===================== [End: 4 - Caller: 3] =====================`**
<br>`00:25:45:723` | 
<br>`00:25:45:723` | 
<br>`00:25:45:723` | 
<br>`00:25:45:723` | **`========== [Early End: 3 - Caller: 2] List Serialized ==========`**
<br>`00:25:45:723` | 
<br>`00:25:45:723` | 
<br>`00:25:45:724` | 
<br>`00:25:45:724` | **`========== [Early End: 2 - Caller: 1] List Serialized ==========`**
<br>`00:25:45:724` | 
<br>`00:25:45:724` | 
<br>`00:25:45:725` |   **`[TypeCheck]`** Checking Type 
<br>`00:25:45:725` |   	&emsp;Value: `[[[{'testParam': 'asd', 'PYON_TYPE': 'test'}]]]`, 
<br>`00:25:45:725` |   	&emsp;Type(s): `<class 'dict'>`
<br>`00:25:45:725` | 
<br>`00:25:45:726` |   **`[TypeCheck]`** Checking Type 
<br>`00:25:45:726` |   	&emsp;Value: `test`, 
<br>`00:25:45:726` |   	&emsp;Type(s): `(<class 'list'>, <class 'tuple'>)`
<br>`00:25:45:726` | 
<br>`00:25:45:727` |   **`[TypeCheck]`** Checking Type 
<br>`00:25:45:727` |   	&emsp;Value: `test`, 
<br>`00:25:45:727` |   	&emsp;Type(s): `<class 'dict'>`
<br>`00:25:45:727` | 
<br>`00:25:45:729` |   **`[1]`** **New dict created:**
<br>`00:25:45:729` |   	&emsp;`{'testParam': [[[{'testParam': 'asd', 'PYON_TYPE': 'test'}]]], 'PYON_TYPE': 'test'}`
<br>`00:25:45:729` | 
<br>`00:25:45:730` | 
<br>`00:25:45:730` | **`=========================== [End: 1] ===========================`**
<br>`00:25:45:730` | 
<br>`00:25:45:730` | 
<br>`00:25:45:731` | 
<br>`00:25:45:731` | **`========================= [Deep Parse] =========================`**
<br>`00:25:45:731` | 
<br>`00:25:45:731` | 
<br>`00:25:45:732` | 
<br>`00:25:45:732` | **`========================== [Start: 1] ==========================`**
<br>`00:25:45:732` | 
<br>`00:25:45:732` | 
<br>`00:25:45:733` |   **`[TypeCheck]`** Checking Type 
<br>`00:25:45:733` |   	&emsp;Value: `{'testParam': [[[{'testParam': 'asd', 'PYON_TYPE': 'test'}]]], 'PYON_TYPE': 'test'}`, 
<br>`00:25:45:733` |   	&emsp;Type(s): `<class 'list'>`
<br>`00:25:45:733` | 
<br>`00:25:45:734` | 
<br>`00:25:45:734` | **`=================== [Deep Parse - Caller: 1] ===================`**
<br>`00:25:45:734` | 
<br>`00:25:45:734` | 
<br>`00:25:45:735` | 
<br>`00:25:45:735` | **`==================== [Start: 2 - Caller: 1] ====================`**
<br>`00:25:45:735` | 
<br>`00:25:45:735` | 
<br>`00:25:45:735` |   **`[TypeCheck]`** Checking Type 
<br>`00:25:45:735` |   	&emsp;Value: `[[{'testParam': 'asd', 'PYON_TYPE': 'test'}]]`, 
<br>`00:25:45:735` |   	&emsp;Type(s): `<class 'list'>`
<br>`00:25:45:735` | 
<br>`00:25:45:736` | 
<br>`00:25:45:736` | **`=================== [Deep Parse - Caller: 2] ===================`**
<br>`00:25:45:736` | 
<br>`00:25:45:736` | 
<br>`00:25:45:737` | 
<br>`00:25:45:737` | **`==================== [Start: 3 - Caller: 2] ====================`**
<br>`00:25:45:737` | 
<br>`00:25:45:737` | 
<br>`00:25:45:737` |   **`[TypeCheck]`** Checking Type 
<br>`00:25:45:737` |   	&emsp;Value: `[{'testParam': 'asd', 'PYON_TYPE': 'test'}]`, 
<br>`00:25:45:737` |   	&emsp;Type(s): `<class 'list'>`
<br>`00:25:45:737` | 
<br>`00:25:45:739` | 
<br>`00:25:45:739` | **`=================== [Deep Parse - Caller: 3] ===================`**
<br>`00:25:45:739` | 
<br>`00:25:45:739` | 
<br>`00:25:45:740` | 
<br>`00:25:45:740` | **`==================== [Start: 4 - Caller: 3] ====================`**
<br>`00:25:45:740` | 
<br>`00:25:45:740` | 
<br>`00:25:45:741` |   **`[TypeCheck]`** Checking Type 
<br>`00:25:45:741` |   	&emsp;Value: `{'testParam': 'asd', 'PYON_TYPE': 'test'}`, 
<br>`00:25:45:741` |   	&emsp;Type(s): `<class 'list'>`
<br>`00:25:45:741` | 
<br>`00:25:45:742` |   **`[4]`** Return Value: 
<br>`00:25:45:742` |   	&emsp;`test(testParam='asd', pyon_converted=True)`
<br>`00:25:45:742` | 
<br>`00:25:45:742` | 
<br>`00:25:45:742` | **`===================== [End: 4 - Caller: 3] =====================`**
<br>`00:25:45:742` | 
<br>`00:25:45:742` | 
<br>`00:25:45:744` |   **`[3]`** Restored Original List:
<br>`00:25:45:744` |   	&emsp;[test(testParam='asd', pyon_converted=True)]
<br>`00:25:45:744` | 
<br>`00:25:45:745` |   **`[3]`** Return Value: 
<br>`00:25:45:745` |   	&emsp;`[test(testParam='asd', pyon_converted=True)]`
<br>`00:25:45:745` | 
<br>`00:25:45:747` | 
<br>`00:25:45:747` | **`===================== [End: 3 - Caller: 2] =====================`**
<br>`00:25:45:747` | 
<br>`00:25:45:747` | 
<br>`00:25:45:747` |   **`[2]`** Restored Original List:
<br>`00:25:45:747` |   	&emsp;[[test(testParam='asd', pyon_converted=True)]]
<br>`00:25:45:747` | 
<br>`00:25:45:749` |   **`[2]`** Return Value: 
<br>`00:25:45:749` |   	&emsp;`[[test(testParam='asd', pyon_converted=True)]]`
<br>`00:25:45:749` | 
<br>`00:25:45:749` | 
<br>`00:25:45:749` | **`===================== [End: 2 - Caller: 1] =====================`**
<br>`00:25:45:749` | 
<br>`00:25:45:749` | 
<br>`00:25:45:750` |   **`[1]`** Return Value: 
<br>`00:25:45:750` |   	&emsp;`test(testParam=[[[test(testParam='asd', pyon_converted=True)]]], pyon_converted=True)`
<br>`00:25:45:750` | 
<br>`00:25:45:751` | 
<br>`00:25:45:751` | **`=========================== [End: 1] ===========================`**
<br>`00:25:45:751` | 
<br>`00:25:45:751` | 